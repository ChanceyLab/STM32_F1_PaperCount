#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define LED PBout(9)
#define BEEP PFout(2)
void LED_Init(void);//��ʼ��
void BEEP_Init(void);


#endif
